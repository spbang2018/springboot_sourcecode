package com.retailbanking.microservicedemo;

import org.springframework.web.bind.annotation.*;

@RestController
public class HelloWorld {

    @GetMapping("/hello")
    public String sayhello() {
        return " Learning microservices";
    }

    @GetMapping("/GetCustomerdetails")
    public String GetCustomerdetails() {
        return " GetCustomerdetails";
    }

    @GetMapping("/getUserDetails")
    @ResponseBody
    public String getUserDetails(@RequestParam String Username, @RequestParam String location) {
        return "ID: " + Username + " Name: " + location;
    }
}
