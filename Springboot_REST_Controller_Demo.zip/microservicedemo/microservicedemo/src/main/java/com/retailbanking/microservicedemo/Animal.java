package com.retailbanking.microservicedemo;

import org.springframework.stereotype.Component;

@Component
public interface Animal {

	public String characteristics();

}
