package com.retailbanking.microservicedemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class bankingmicrosrvice {

    @GetMapping("/syhello")
    public String sayhello()
    {
        return " Learning microservices";
    }
    @GetMapping("/getbankdetails")
    public String bankdetails()
    {
        return " return bankdetails";
    }
}
