package com.retailbanking.microservicedemo;

public class Dog implements Animal {

	@Override
	public String characteristics() {
		// TODO Auto-generated method stub
		return "Bark";
	}
}
