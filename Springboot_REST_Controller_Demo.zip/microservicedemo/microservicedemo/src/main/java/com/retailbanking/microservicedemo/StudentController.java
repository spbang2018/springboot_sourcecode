package com.retailbanking.microservicedemo;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.*;

@RestController
public class StudentController {

    // http://localhost:80/student
    @GetMapping("/student")
    public Student getStudent() {
        return new Student("Siva", "Bangalore");
    }

    @GetMapping("/students")
    public List<Student> getStudents(){
        List<Student> students = new ArrayList<>();
        students.add(new Student("Ramesh", "Fadatare"));
        students.add(new Student("Tony", "Cena"));
        students.add(new Student("Sanjay", "Jadhav"));
        students.add(new Student("Ram", "Jadhav"));
        students.add(new Student("Umesh", "Fadatare"));
        return students;
    }

    // http://localhost:80/student/1 or http://localhost:80/student/siva/banagalore/
    // @PathVariable annotation
    @GetMapping("/student/{firstName}/{lastName}/")
    public Student studentPathVariable(@PathVariable("firstName") String firstName,
                                       @PathVariable("lastName") String lastName) {
        return new Student(firstName, lastName);
    }

    // build rest API to handle query parameters
    // http://localhost:80/student/query?firstName=Ramesh&lastName=Fadatare
    @GetMapping("/student/query")
    public Student studentQueryParam(
            @RequestParam(name = "firstName") String firstName,
            @RequestParam(name = "lastName") String lastName) {
        return new Student(firstName, lastName);
    }

    // send Object as an input
    // http://localhost:80/student/CreateRecord
    @PostMapping("/student/CreateRecord")
    public String CreateStudent(@RequestBody Student student) {
        Student StudentInst=student;
        System.out.println("Student First name"+StudentInst.getFirstName());
        return StudentInst.getFirstName();
    }

    @PostMapping("/student/new-registration")
    public @ResponseBody Student register(@RequestBody Student student) {
        return student;
    }

}
