package com.springboot.beanscope;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(DemoApplication.class, args);
        SingletonBean beanA = (SingletonBean) context.getBean(SingletonBean.class);
        beanA.setMessage("Message by custA");
        System.out.println("Message : " + beanA.getMessage());

        //retrieve it again
        SingletonBean beanB = (SingletonBean)context.getBean(SingletonBean.class);
        System.out.println("Message : " + beanB.getMessage());

        PrototypeBean beanC = (PrototypeBean) context.getBean(PrototypeBean.class);
        beanC.setMessage("Message by custC");
        System.out.println("Message : " + beanC.getMessage());

        //retrieve it again
        PrototypeBean beanD = (PrototypeBean)context.getBean(PrototypeBean.class);
        System.out.println("Message : " + beanD.getMessage());
    }
    }
