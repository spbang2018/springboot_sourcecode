package com.springboot.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
//@Primary
@Service
public class Dog implements Animal {

	@Override
	public String characteristics() {
		// TODO Auto-generated method stub
		return "Bark";
	}
}
