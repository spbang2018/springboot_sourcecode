package com.javatechie.spring.batch.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class scheduler {

    @Autowired
    private JobLauncher jobLauncher;
    @Autowired
    private Job job;

    // run the job every 5 mts
    @Scheduled(fixedRate = 5000, initialDelay = 5000)
    public void scheduleFixedDelayTask()
    {
        System.out.println( "job started every 5 mts");
        System.out.println( "Fixed delay task - " + System.currentTimeMillis() / 1000);
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("startAt", System.currentTimeMillis()).toJobParameters();

        System.out.println( "job ended every 5 mts");
        
        // Implement Business Logic
        //Step1: Read the CSV file and store java pojo object
        //Step2 :Store the data into dynamo DB
        
        
        try {
            jobLauncher.run(job, jobParameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException |
                 JobParametersInvalidException e) {
            e.printStackTrace();
        }

    }

    // run the job every 15 mts
    @Scheduled(cron = "0 0/15 * * * *")
    public void scheduleFixedDelayTask2()
    {
        System.out.println( "job started every 15 mts");
        System.out.println( "Fixed delay task - " + System.currentTimeMillis() / 1000);
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("startAt", System.currentTimeMillis()).toJobParameters();

        System.out.println( "job ended every 5 mts");
        try {
            jobLauncher.run(job, jobParameters);
        } catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException |
                 JobParametersInvalidException e) {
            e.printStackTrace();
        }

    }

}
