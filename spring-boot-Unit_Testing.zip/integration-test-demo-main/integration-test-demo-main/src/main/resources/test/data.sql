INSERT INTO PRODUCT_TBL (name, quantity, price) VALUES
  ('Book', 1, 499),
  ('mobile', 1, 999);