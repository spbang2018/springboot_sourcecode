# spring-boot-powermock
how to mock final, static or private methods using powermock
